from bunny_logic import *

def level1():
    bunny_group = []
    special_logic = 1
    level_background = background1_list

    return bunny_group, special_logic, level_background

def level2():
    bunny_group = []
    special_logic = 2
    level_background = background2_list

    return bunny_group, special_logic, level_background